﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GID_Client.TsexLogic
{
    class CertificateProcess : ICertificateProcess
    {
        public bool mondatoryFlag
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public bool Process()
        {
            throw new NotImplementedException();
        }
    }
}
