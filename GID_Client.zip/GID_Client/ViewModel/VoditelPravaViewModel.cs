﻿using Epigov.Log;
using CardAPILib.CardAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Iso18013Lib;
using System.Globalization;

namespace GID_Client.ViewModel
{
    internal class VoditelPravaViewModel : ViewModelBase
    {
        private readonly ILogService _logService;

        private CardApiController _controller;

        public RelayCommand ReadCard { get; private set; }

        public VoditelPravaViewModel()
        {
            _logService = new FileLogService(typeof(InitCardViewModel));

            ReadCard = new RelayCommand(_ => fReadCard());

            _controller = new CardApiController(true);
        }

        private void fReadCard()
        {
            byte[] DG1 = null;

            byte[] DG2 = null;

            byte[] DG3 = null;

            byte[] DG4 = null;

            byte[] DG5 = null;

            byte[] DGCommon = null;

            try
            {
                var result = _controller.ReadIDLCard(ref DG1, ref DG2, ref DG3, ref DG4, ref DG5, ref DGCommon);

                if (result != 0)
                {
                    StatusText = "Ошибка при прочтении карты";

                    _logService.Error(string.Format("{0} {1}", "Ошибка при прочтении карты", result));

                    return;
                }

                DrivingLicense DrL = new DrivingLicense("");

                var dl = DrL.ParseReadMaterial(DG1, DG2, DG3, DG4, DG5, DGCommon);

                LastName = dl._driver._last_name;

                FirstName = dl._driver._first_name;

                MiddleName = dl._driver._middle_name;

                // dl._driver._date_of_birth
                // dl._issue_date
                // dl._expire_date

                BirthDate = DateTime.ParseExact(dl._driver._date_of_birth, "yyyyMMdd", CultureInfo.InvariantCulture);

                IssueDate = DateTime.ParseExact(dl._issue_date, "yyyyMMdd", CultureInfo.InvariantCulture);

                ExpireDate = DateTime.ParseExact(dl._expire_date, "yyyyMMdd", CultureInfo.InvariantCulture);

            }
            catch (Exception ex)
            {
                StatusText = "Ошибка при прочтении карты";

                _logService.Error(string.Format("{0} {1}", "Ошибка при прочтении карты", ex.Message));
            }

        }

        private string _lastName;

        public string LastName
        {
            get { return _lastName; }

            set
            {
                _lastName = value;

                OnPropertyChanged("LastName");
            }
        }

        private string _firstName;


        public string FirstName
        {
            get { return _firstName; }

            set
            {
                _firstName = value;

                OnPropertyChanged("FirstName");
            }
        }

        private string _middleName;


        public string MiddleName
        {
            get { return _middleName; }

            set
            {
                _middleName = value;

                OnPropertyChanged("MiddleName");
            }
        }

        private bool _isIntermadiate;

        public bool IsIntermadiate
        {
            get
            {
                return _isIntermadiate;
            }

            set
            {
                _isIntermadiate = value;

                OnPropertyChanged("IsIntermadiate");
            }
        }


        private DateTime _birthDate;

        public DateTime BirthDate
        {
            get { return _birthDate; }

            set
            {
                _birthDate = value;

                OnPropertyChanged("BirthDate");
            }
        }

        private DateTime _issueDate;

        public DateTime IssueDate
        {
            get { return _issueDate; }

            set
            {
                _issueDate = value;

                OnPropertyChanged("IssueDate");
            }
        }

        private DateTime _expireDate;

        public DateTime ExpireDate
        {
            get { return _expireDate; }

            set
            {
                _expireDate = value;

                OnPropertyChanged("ExpireDate");
            }
        }

        private string _statusText;

        public string StatusText
        {
            get
            {
                return _statusText;
            }

            set
            {
                _statusText = value;

                OnPropertyChanged("StatusText");
            }
        }
    }
}
