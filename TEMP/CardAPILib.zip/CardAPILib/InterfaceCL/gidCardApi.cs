﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GemCard;
using log4net;
using System.Security.Cryptography;
using System.IO;

namespace CardAPILib.InterfaceCL
{
    public partial class CardApiMessages
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int OpenCardCommands()
        {
            try
            {
                {
                    #region 00 A4 04 00 [10] 38 0A 23 63 DB 70 76 31 9F A6 8E 27 71 D1 39 85 [00]
                    APDUCommand apduSize = new APDUCommand(0x00, 0xA4, 0x04, 0x00, null, 0);

                    APDUParam apduParam = new APDUParam();

                    apduParam.Data = new byte[16] { 0x38, 0x0A, 0x23, 0x63, 0xDB, 0x70, 0x76, 0x31, 0x9F, 0xA6, 0x8E, 0x27, 0x71, 0xD1, 0x39, 0x85 };

                    apduSize.Update(apduParam);

                    apduResp = iCard.Transmit(apduSize);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }
                {
                    #region 00 F0 00 00
                    APDUCommand apduSize2 = new APDUCommand(0x00, 0xF0, 0x00, 0x00, null, 0);

                    apduResp = iCard.Transmit(apduSize2);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }
                    #endregion
                }

                {
                    #region C0 B0 05 B6 [10]
                    APDUCommand apduSize2_1 = new APDUCommand(0xC0, 0xB0, 0x05, 0xB6, null, 10);

                    apduResp = iCard.Transmit(apduSize2_1);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }
                    #endregion
                }

                {
                    #region C0 D6 05 B6 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F
                    APDUCommand apduSize3 = new APDUCommand(0xC0, 0xD6, 0x05, 0xB6, null, 0);

                    APDUParam apduParam3 = new APDUParam();

                    apduParam3.Data = new byte[16] { 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F };

                    apduSize3.Update(apduParam3);

                    apduResp = iCard.Transmit(apduSize3);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File Not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region C0 B0 05 E6 [10]
                    APDUCommand apduSize3_1 = new APDUCommand(0xC0, 0xB0, 0x05, 0xE6, null, 10);

                    apduResp = iCard.Transmit(apduSize3_1);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region C0 D6 05 E6 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F
                    APDUCommand apduSize4 = new APDUCommand(0xC0, 0xD6, 0x05, 0xE6, null, 0);

                    APDUParam apduParam4 = new APDUParam();

                    apduParam4.Data = new byte[16] { 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F };

                    apduSize4.Update(apduParam4);

                    apduResp = iCard.Transmit(apduSize4);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region C0 B0 06 16 [10]
                    APDUCommand apduSize4_1 = new APDUCommand(0xC0, 0xB0, 0x06, 0x16, null, 10);

                    apduResp = iCard.Transmit(apduSize4_1);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region C0 D6 06 16 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F

                    APDUCommand apduSize5 = new APDUCommand(0xC0, 0xD6, 0x06, 0x16, null, 0);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[16] { 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File Not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }
                    #endregion
                }

                {
                    #region C0 B0 02 FC [01]

                    APDUCommand apduSize6 = new APDUCommand(0xC0, 0xB0, 0x02, 0xFC, null, 1);

                    apduResp = iCard.Transmit(apduSize6);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region C0 D6 02 FC [01] 96
                    APDUCommand apduSize6_1 = new APDUCommand(0xC0, 0xD6, 0x02, 0xFC, null, 0);

                    APDUParam apduParam6_1 = new APDUParam();

                    apduParam6_1.Data = new byte[1] { 0x96 };

                    apduSize6_1.Update(apduParam6_1);

                    apduResp = iCard.Transmit(apduSize6_1);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region C0 B0 03 1F [01]

                    APDUCommand apduSize6_2 = new APDUCommand(0xC0, 0xB0, 0x03, 0x1F, null, 0);

                    apduResp = iCard.Transmit(apduSize6_2);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region C0 D6 03 1F [01] 96
                    APDUCommand apduSize6_3 = new APDUCommand(0xC0, 0xD6, 0x03, 0x1F, null, 0);

                    APDUParam apduParam6_3 = new APDUParam();

                    apduParam6_3.Data = new byte[1] { 0x96 };

                    apduSize6_3.Update(apduParam6_3);

                    apduResp = iCard.Transmit(apduSize6_3);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not Found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                {
                    #region 00 10 00 00

                    APDUCommand apduSize7 = new APDUCommand(0x00, 0x10, 0x00, 0x00, null, 0);

                    apduResp = iCard.Transmit(apduSize7);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            string code = "File not found";
                            LastOperationStatus = code;
                            log.Error(code);

                            return 100;
                        }

                        return 101;
                    }

                    #endregion
                }

                iCard.Disconnect(DISCONNECT.Reset);

                Connect2Card();

            }
            catch (Exception ex)
            {
                log.Info(ex.Message);

                return 101;
            }

            return 0;
        }

        private int ExternalAuth()
        {
            byte[] key = new byte[16];

            #region Keys
            key[0] = 0x40;
            key[1] = 0x41;
            key[2] = 0x42;
            key[3] = 0x43;
            key[4] = 0x44;
            key[5] = 0x45;
            key[6] = 0x46;
            key[7] = 0x47;
            key[8] = 0x48;
            key[9] = 0x49;
            key[10] = 0x4A;
            key[11] = 0x4B;
            key[12] = 0x4C;
            key[13] = 0x4D;
            key[14] = 0x4E;
            key[15] = 0x4F;
            #endregion

            byte[] InitializeUpdateReturn = new byte[28];


            byte[] secureRandomBytes = SecureRandom.GetBytes(8);

            byte[] EXTERNAL_AUTHENTICATE_data = new byte[8];

            {
                #region 00 A4 04 00 [08] A0 00 00 01 51 00 00 00 [00]
                APDUCommand apduSize6_3 = new APDUCommand(0x00, 0xA4, 0x04, 0x00, null, 0);

                APDUParam apduParam6_3 = new APDUParam();

                apduParam6_3.Data = new byte[8] { 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00 };

                apduSize6_3.Update(apduParam6_3);

                apduResp = iCard.Transmit(apduSize6_3);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {
                    if (apduResp.ToString().Contains("6A82"))
                    {
                        string code = "File not Found";
                        LastOperationStatus = code;
                        log.Error(code);

                        return 100;
                    }

                    return 101;
                }

                #endregion
            }

            {
                #region 80 CA 00 66 [01]

                APDUCommand apduSize6_2 = new APDUCommand(0x80, 0xCA, 0x00, 0x66, null, 0);

                apduResp = iCard.Transmit(apduSize6_2);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {
                    if (apduResp.ToString().Contains("6A82"))
                    {
                        string code = "File not Found";
                        LastOperationStatus = code;
                        log.Error(code);

                        return 100;
                    }

                    return 101;
                }

                #endregion
            }

            {
                #region 80 50 00 00 [08] 
                APDUCommand apduSize6_3 = new APDUCommand(0x80, 0x50, 0x00, 0x00, null, 0);

                APDUParam apduParam6_3 = new APDUParam();

                apduParam6_3.Data = secureRandomBytes;

                apduSize6_3.Update(apduParam6_3);

                apduResp = iCard.Transmit(apduSize6_3);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {
                    if (apduResp.ToString().Contains("6A82"))
                    {
                        string code = "File not Found";
                        LastOperationStatus = code;
                        log.Error(code);

                        return 100;
                    }

                    return 101;
                }

                Array.Copy(apduResp.Data, InitializeUpdateReturn, 28);

                #region DerivasionData
                byte[] derivation_data = new byte[16];

                //01 82 00 04 00 00 00 00 00 00 00 00 00 00 00 00

                derivation_data[0] = 0x01;
                derivation_data[1] = 0x82;
                derivation_data[2] = InitializeUpdateReturn[12];
                derivation_data[3] = InitializeUpdateReturn[13]; 
                derivation_data[4] = 0x00;
                derivation_data[5] = 0x00;
                derivation_data[6] = 0x00;
                derivation_data[7] = 0x00;
                derivation_data[8] = 0x00;
                derivation_data[9] = 0x00;
                derivation_data[10] = 0x00;
                derivation_data[11] = 0x00;
                derivation_data[12] = 0x00;
                derivation_data[13] = 0x00;
                derivation_data[14] = 0x00;
                derivation_data[15] = 0x00;

                #endregion

                byte[] encData = encrypt3DES(key, derivation_data);

                byte[] host_auth_data = new byte[24];
                //sequence_counter
                host_auth_data[0] = InitializeUpdateReturn[12];
                host_auth_data[1] = InitializeUpdateReturn[13];

                //card_challenge
                host_auth_data[2] = InitializeUpdateReturn[14];
                host_auth_data[3] = InitializeUpdateReturn[15];
                host_auth_data[4] = InitializeUpdateReturn[16];
                host_auth_data[5] = InitializeUpdateReturn[17];
                host_auth_data[6] = InitializeUpdateReturn[18];
                host_auth_data[7] = InitializeUpdateReturn[19];

                //host_challenge
                host_auth_data[8] = secureRandomBytes[0];
                host_auth_data[9] = secureRandomBytes[1];
                host_auth_data[10] = secureRandomBytes[2];
                host_auth_data[11] = secureRandomBytes[3];
                host_auth_data[12] = secureRandomBytes[4];
                host_auth_data[13] = secureRandomBytes[5];
                host_auth_data[14] = secureRandomBytes[6];
                host_auth_data[15] = secureRandomBytes[7];

                host_auth_data[16] = 0x80;
                host_auth_data[17] = 0x00;
                host_auth_data[18] = 0x00;
                host_auth_data[19] = 0x00;
                host_auth_data[20] = 0x00;
                host_auth_data[21] = 0x00;
                host_auth_data[22] = 0x00;
                host_auth_data[23] = 0x00;

                byte[] host_cryptogram = encrypt3DES(encData, host_auth_data);

                byte[] ExternalAuthData = new byte[8];
                
                EXTERNAL_AUTHENTICATE_data[0] = host_cryptogram[16];
                EXTERNAL_AUTHENTICATE_data[1] = host_cryptogram[17];
                EXTERNAL_AUTHENTICATE_data[2] = host_cryptogram[18];
                EXTERNAL_AUTHENTICATE_data[3] = host_cryptogram[19];
                EXTERNAL_AUTHENTICATE_data[4] = host_cryptogram[20];
                EXTERNAL_AUTHENTICATE_data[5] = host_cryptogram[21];
                EXTERNAL_AUTHENTICATE_data[6] = host_cryptogram[22];
                EXTERNAL_AUTHENTICATE_data[7] = host_cryptogram[23];

                //Generate MAC

                #endregion
            }




            return 0;
        }

        public int CheckStatus()
        {



            return 0;
        }

        private  TripleDESCryptoServiceProvider e1 = new TripleDESCryptoServiceProvider();
        private DESCryptoServiceProvider d1 = new DESCryptoServiceProvider();


        public byte[] encryptDES(byte[] key, byte[] data)
        {
            d1.IV = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
            if (key.Length != 0x08 &&
                key.Length != 0x10 &&
                key.Length != 0x18)
                throw new Exception("Invalid key length");
            d1.Padding = PaddingMode.None;
            d1.Mode = CipherMode.CBC;
            d1.Key = key;

            using (var ms = new MemoryStream())
            {
                using (var cs = new CryptoStream(ms, d1.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(data, 0, data.Length);
                }

                return ms.ToArray();
            }

        }

        public byte[] encrypt3DES(byte[] key, byte[] data)
        {
            e1.IV = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
            if (key.Length != 0x08 &&
                key.Length != 0x10 &&
                key.Length != 0x18)
                throw new Exception("Invalid key length");
            e1.Padding = PaddingMode.None;
            e1.Mode = CipherMode.CBC;
            e1.Key = key;

            using (var ms = new MemoryStream())
            {
                using (var cs = new CryptoStream(ms, e1.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(data, 0, data.Length);
                }

                return ms.ToArray();
            }
        }

        public byte[] Algorithm3(byte[] data, byte[] key, byte[] icv)
        {
            if (data.Length % 8 != 0)
            {
                throw new ArgumentException("Data must be padded to 8-byte blocks.", nameof(data));
            }

            //Ensure.HasCount(key, nameof(key), 16);
            if (key.Length != 16)
            {
                throw new ArgumentException("key.Length must be 16 bytes", nameof(key));
            }

            //Ensure.HasCount(icv, nameof(icv), 8);
            if (icv.Length != 8)
            {
                throw new ArgumentException("icv.Length must be 8 bytes", nameof(icv));
            }

            int numBlocks = data.Length / 8;

            byte[] iv;

            if (numBlocks > 1)
            {
                byte[] firstBlocks = data.Take((numBlocks - 1) * 8).ToArray();

                byte[] encFirstBlocks = encryptDES(firstBlocks, key.Take(8).ToArray(), icv, CipherMode.CBC);

                iv = encFirstBlocks.TakeLast(8).ToArray();
            }
            else
            {
                iv = icv;
            }

            byte[] lastBlock = data.TakeLast(8).ToArray();
            byte[] encLastBlock = TripleDES.Encrypt(lastBlock, key, iv, CipherMode.CBC);
            byte[] mac = encLastBlock.TakeLast(8).ToArray();

            return mac;
        }
    }
}
