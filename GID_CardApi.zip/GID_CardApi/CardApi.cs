﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GemCard;
using System.Threading;
using Iso18013Lib;
using CardAPILib.CardAPI;

namespace GID_CardApi
{
    public class CardApi
    {

        private static APDUResponse apduResp;

        private static CardNative iCard;
        private static CardApiController _controller = new CardApiController(true); 
        private const ushort SC_OK = 0x9000;
        private const byte SC_PENDING = 0x9F;

        private static int Connect2Card()
        {
            try
            {

                string[] readers = iCard.ListReaders();

                string[] SpecReaders = (from reader in readers
                                        where reader.Contains("CL")
                                        select reader).ToArray();


                foreach (string readerInfo in SpecReaders)
                {
                    try
                    {
                        iCard.Disconnect(DISCONNECT.Unpower);

                    }
                    catch (Exception)
                    {
                        //
                    }

                    try
                    {
                        iCard.Connect(readerInfo, SHARE.Shared, PROTOCOL.T0orT1);

                        return 0;
                    }
                    catch (Exception)
                    {
                        //throw new ApduCommandException("Uneble to connect to Card");
                    }
                }

            }
            catch (Exception ex)
            {

                throw new ApduCommandException("Uneble to connect to Card");
            }

            return -1;
        }

        private static Task<int> Save2CardDriver(string content)
        {
            var resultTask = Task.Factory.StartNew(() =>
            {
                int result = 0;

                DrivingLicense dl = new DrivingLicense(content);

                if (dl.ParseInputJson() == 0)
                {
                    result = _controller.SaveIDL2Card(dl.GetDG1x(), dl.GetDG2x(), dl.GetDG3x(), dl.GetDG4x(), dl.GetDG5(), dl.GetCommon());
                }

                return result;
            });

            return resultTask;
        }

        public static async Task<int> WriteDriverInfo(string jsonFData)
        {
            if (iCard ==null)
                iCard = new CardNative();

            //var result = Connect2Card();

            //if (result != 0)
            //{
            //    return result;
            //}

            if (string.IsNullOrEmpty(jsonFData))
            {
                return -2;
            }

            var res = await Save2CardDriver(jsonFData);

            return res;
        }

    }
}
