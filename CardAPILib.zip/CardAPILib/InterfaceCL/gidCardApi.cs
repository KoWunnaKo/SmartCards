﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GemCard;
using log4net;
using System.Security.Cryptography;
using System.IO;
using System.Threading;

namespace CardAPILib.InterfaceCL
{
    public enum CardFactoryMode
    {
        DrivingLicence,
        VehicleRegistration
    }

    public partial class CardApiMessages
    {

        ExternalAuthentificate extr = new ExternalAuthentificate();
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int OpenCardCommands(CardFactoryMode mode)
        {
            bool preApdu = false;

            log.Info("OpenCardCommands");

            log.Info(mode.ToString());

            try
            {
                Connect2Card();

                {
                    log.Info("00 A4 04 00 [10] 38 0A 23 63 DB 70 76 31 9F A6 8E 27 71 D1 39 85 [00]");
                    #region 00 A4 04 00 [10] 38 0A 23 63 DB 70 76 31 9F A6 8E 27 71 D1 39 85 [00]
                    APDUCommand apduSize = new APDUCommand(0x00, 0xA4, 0x04, 0x00, null, 0);

                    APDUParam apduParam = new APDUParam();

                    apduParam.Data = new byte[16] { 0x38, 0x0A, 0x23, 0x63, 0xDB, 0x70, 0x76, 0x31, 0x9F, 0xA6, 0x8E, 0x27, 0x71, 0xD1, 0x39, 0x85 };

                    apduSize.Update(apduParam);

                    apduResp = iCard.TransmitLe(apduSize);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        if (apduResp.ToString().Contains("6A82"))
                        {
                            preApdu = true;
                        }

                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        //return -1;
                    }

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());

                    Thread.Sleep(100);

                    #endregion
                }

                if (!preApdu)
                {
                    {
                        log.Info("00 F0 00 00");
                        #region 00 F0 00 00
                        APDUCommand apduSize2 = new APDUCommand(0x00, 0xF0, 0x00, 0x00, null, 0);

                        apduResp = iCard.Transmit(apduSize2);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -2;
                        }

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());

                        #endregion
                    }

                    {
                        log.Info("C0 B0 05 B6 [10]");
                        #region C0 B0 05 B6 [10]
                        APDUCommand apduSize2_1 = new APDUCommand(0xC0, 0xB0, 0x05, 0xB6, null, 10);

                        apduResp = iCard.Transmit(apduSize2_1);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -3;
                        }
                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 D6 05 B6 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F");
                        #region C0 D6 05 B6 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F
                        APDUCommand apduSize3 = new APDUCommand(0xC0, 0xD6, 0x05, 0xB6, null, 0);

                        APDUParam apduParam3 = new APDUParam();

                        apduParam3.Data = new byte[16] { 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F };

                        apduSize3.Update(apduParam3);

                        apduResp = iCard.Transmit(apduSize3);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -4;
                        }

                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 B0 05 E6 [10]");
                        #region C0 B0 05 E6 [10]
                        APDUCommand apduSize3_1 = new APDUCommand(0xC0, 0xB0, 0x05, 0xE6, null, 10);

                        apduResp = iCard.Transmit(apduSize3_1);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {

                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -5;
                        }

                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 D6 05 E6 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F");
                        #region C0 D6 05 E6 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F
                        APDUCommand apduSize4 = new APDUCommand(0xC0, 0xD6, 0x05, 0xE6, null, 0);

                        APDUParam apduParam4 = new APDUParam();

                        apduParam4.Data = new byte[16] { 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F };

                        apduSize4.Update(apduParam4);

                        apduResp = iCard.Transmit(apduSize4);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {

                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -6;
                        }

                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 B0 06 16 [10]");
                        #region C0 B0 06 16 [10]
                        APDUCommand apduSize4_1 = new APDUCommand(0xC0, 0xB0, 0x06, 0x16, null, 10);

                        apduResp = iCard.Transmit(apduSize4_1);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -7;
                        }

                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 D6 06 16 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F");
                        #region C0 D6 06 16 [10] 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F

                        APDUCommand apduSize5 = new APDUCommand(0xC0, 0xD6, 0x06, 0x16, null, 0);

                        APDUParam apduParam5 = new APDUParam();

                        apduParam5.Data = new byte[16] { 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F };

                        apduSize5.Update(apduParam5);

                        apduResp = iCard.Transmit(apduSize5);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -8;
                        }
                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 B0 02 FC [01]");
                        #region C0 B0 02 FC [01]

                        APDUCommand apduSize6 = new APDUCommand(0xC0, 0xB0, 0x02, 0xFC, null, 1);

                        apduResp = iCard.Transmit(apduSize6);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -9;
                        }

                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 D6 02 FC [01] 96");
                        #region C0 D6 02 FC [01] 96
                        APDUCommand apduSize6_1 = new APDUCommand(0xC0, 0xD6, 0x02, 0xFC, null, 0);

                        APDUParam apduParam6_1 = new APDUParam();

                        apduParam6_1.Data = new byte[1] { 0x96 };

                        apduSize6_1.Update(apduParam6_1);

                        apduResp = iCard.Transmit(apduSize6_1);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -10;
                        }

                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 B0 03 1F [01]");
                        #region C0 B0 03 1F [01]

                        APDUCommand apduSize6_2 = new APDUCommand(0xC0, 0xB0, 0x03, 0x1F, null, 1);

                        apduResp = iCard.Transmit(apduSize6_2);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -11;
                        }

                        #endregion


                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("C0 D6 03 1F [01] 96");
                        #region C0 D6 03 1F [01] 96
                        APDUCommand apduSize6_3 = new APDUCommand(0xC0, 0xD6, 0x03, 0x1F, null, 0);

                        APDUParam apduParam6_3 = new APDUParam();

                        apduParam6_3.Data = new byte[1] { 0x96 };

                        apduSize6_3.Update(apduParam6_3);

                        apduResp = iCard.Transmit(apduSize6_3);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -12;
                        }

                        #endregion

                        Thread.Sleep(100);


                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }

                    {
                        log.Info("00 10 00 00");
                        #region 00 10 00 00

                        APDUCommand apduSize7 = new APDUCommand(0x00, 0x10, 0x00, 0x00, null, 0);

                        apduResp = iCard.Transmit(apduSize7);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            LastOperationStatus = apduResp.ToString();
                            log.Error(apduResp.ToString());

                            return -13;
                        }

                        #endregion

                        Thread.Sleep(100);

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }
                }

                //RESET PART BEGIN
                iCard.Disconnect(DISCONNECT.Reset);

                Connect2Card();

                iCard.Disconnect(DISCONNECT.Unpower);

                Connect2Card();

                iCard.Disconnect(DISCONNECT.Eject);

                Connect2Card();

                iCard.Disconnect(DISCONNECT.Leave);

                Connect2Card();

                Thread.Sleep(5000);

                if (Connect2Card() != 0)
                {
                    LastOperationStatus = "Connction not estableshed";
                    log.Error(-15);

                    return -15;
                }

                //RESET PART END
                for(int i = 0; i <= 10; i++)
                {
                    Thread.Sleep(1000);

                    iCard.Disconnect(DISCONNECT.Reset);

                    Connect2Card();

                    if (extr.ExternalAuth() != 0)
                    {
                        LastOperationStatus = "ExternalAuth not estableshed";
                        log.Error(-16);
                    }
                }


                #region install for load
                /*
CMD:  80 E6 02 00 [17] 07 A0 00 00 00 62 02 02 08 A0 00 00 01 51 00 00 00 00 03 35 01 08 00 ++
RES:  00 [9000]
CMD:  80 E6 02 00 [17] 07 A0 00 00 01 32 00 01 08 A0 00 00 01 51 00 00 00 00 03 35 01 0A 00 ++
RES:  00 [9000]
CMD:  80 E6 02 00 [18] 08 D2 76 00 00 98 6C 69 62 08 A0 00 00 01 51 00 00 00 00 03 35 01 0C 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [19] 09 D2 76 00 00 98 63 6F 72 65 08 A0 00 00 01 51 00 00 00 00 03 35 01 0E 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [18] 08 D2 76 00 00 98 65 78 74 08 A0 00 00 01 51 00 00 00 00 03 35 01 10 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [1B] 0B D2 76 00 00 98 63 6F 72 65 6B 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 12 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [18] 08 D2 76 00 00 98 4C 44 53 08 A0 00 00 01 51 00 00 00 00 03 35 01 1C 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [1C] 0C D2 76 00 00 98 54 52 30 33 31 31 30 08 A0 00 00 01 51 00 00 00 00 03 35 01 1E 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [1B] 0B D2 76 00 00 98 63 6F 72 65 61 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 14 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [1C] 0C D2 76 00 00 98 63 6F 72 65 62 69 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 16 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [1D] 0D D2 76 00 00 98 63 6F 72 65 72 75 6C 65 08 A0 00 00 01 51 00 00 00 00 03 35 01 18 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [19] 09 D2 76 00 00 98 61 75 74 68 08 A0 00 00 01 51 00 00 00 00 03 35 01 1A 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [15] 05 D2 76 00 00 98 08 A0 00 00 01 51 00 00 00 00 03 35 01 24 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [17] 07 D2 76 00 00 98 4D 44 08 A0 00 00 01 51 00 00 00 00 03 35 01 26 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [18] 08 D2 76 00 00 98 45 41 43 08 A0 00 00 01 51 00 00 00 00 03 35 01 28 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [18] 08 D2 76 00 00 98 65 49 44 08 A0 00 00 01 51 00 00 00 00 03 35 01 22 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [18] 08 D2 76 00 00 98 50 4B 49 08 A0 00 00 01 51 00 00 00 00 03 35 01 2A 00++
RES:  00 [9000]
CMD:  80 E6 02 00 [18] 08 D2 76 00 00 98 49 41 53 08 A0 00 00 01 51 00 00 00 00 03 35 01 20 00++
RES:  00 [9000]

                 */
                #endregion

                bool installLoadFail = false;

                {
                    log.Info("80 E6 02 00 [17] 07 A0 00 00 00 62 02 02 08 A0 00 00 01 51 00 00 00 00 03 35 01 08 00");
                    #region 80 E6 02 00 [17] 07 A0 00 00 00 62 02 02 08 A0 00 00 01 51 00 00 00 00 03 35 01 08 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[23] { 0x07, 0xA0, 0x00, 0x00, 0x00, 0x62, 0x02, 0x02, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x08, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                             LastOperationStatus = apduResp.ToString();
                             log.Error(apduResp.ToString());

                             extr.ExternalAuth();

                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [17] 07 A0 00 00 01 32 00 01 08 A0 00 00 01 51 00 00 00 00 03 35 01 0A 00");
                    #region 80 E6 02 00 [17] 07 A0 00 00 01 32 00 01 08 A0 00 00 01 51 00 00 00 00 03 35 01 0A 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[23] { 0x07, 0xA0, 0x00, 0x00, 0x01, 0x32, 0x00, 0x01, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x0A, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                        //return -18;
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [18] 08 D2 76 00 00 98 6C 69 62 08 A0 00 00 01 51 00 00 00 00 03 35 01 0C 00");
                    #region 80 E6 02 00 [18] 08 D2 76 00 00 98 6C 69 62 08 A0 00 00 01 51 00 00 00 00 03 35 01 0C 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[24] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x6C, 0x69, 0x62, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x0C, 0x00 };

                    apduSize5.Update(apduParam5);

                    log.Info(apduSize5.ToString());

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                        //return -19;
                    }
                    else
                    {
                        installLoadFail = true;
                    }

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                    #endregion
                }

                {
                    log.Info("80 E6 02 00 [19] 09 D2 76 00 00 98 63 6F 72 65 08 A0 00 00 01 51 00 00 00 00 03 35 01 0E 00");
                    #region 80 E6 02 00 [19] 09 D2 76 00 00 98 63 6F 72 65 08 A0 00 00 01 51 00 00 00 00 03 35 01 0E 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[25] { 0x09, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x63, 0x6F, 0x72, 0x65, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x0E, 0x00 };

                    apduSize5.Update(apduParam5);

                    log.Info(apduSize5.ToString());

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }

                    log.Info(apduResp.ToString());

                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [18] 08 D2 76 00 00 98 65 78 74 08 A0 00 00 01 51 00 00 00 00 03 35 01 10 00");

                    #region 80 E6 02 00 [18] 08 D2 76 00 00 98 65 78 74 08 A0 00 00 01 51 00 00 00 00 03 35 01 10 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[24] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x65, 0x78, 0x74, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x10, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [1B] 0B D2 76 00 00 98 63 6F 72 65 6B 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 12 00");

                    #region 80 E6 02 00 [1B] 0B D2 76 00 00 98 63 6F 72 65 6B 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 12 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[27] { 0x0B ,0xD2 ,0x76 ,0x00 ,0x00 ,0x98 ,0x63 ,0x6F ,0x72 ,0x65 ,0x6B ,0x6F ,0x08 ,0xA0 ,0x00 ,0x00 ,0x01 ,0x51 ,0x00 ,0x00 ,0x00 ,0x00 ,0x03 ,0x35 ,0x01 ,0x12 ,0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [18] 08 D2 76 00 00 98 4C 44 53 08 A0 00 00 01 51 00 00 00 00 03 35 01 1C 00");

                    #region 80 E6 02 00 [18] 08 D2 76 00 00 98 4C 44 53 08 A0 00 00 01 51 00 00 00 00 03 35 01 1C 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[24] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x4C, 0x44, 0x53, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x1C, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth(); 
                    }
                    else
                    {
                        installLoadFail = true;
                    }

                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [1C] 0C D2 76 00 00 98 54 52 30 33 31 31 30 08 A0 00 00 01 51 00 00 00 00 03 35 01 1E 00");

                    #region 80 E6 02 00 [1C] 0C D2 76 00 00 98 54 52 30 33 31 31 30 08 A0 00 00 01 51 00 00 00 00 03 35 01 1E 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[28] { 0x0C, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x54, 0x52, 0x30, 0x33, 0x31, 0x31, 0x30, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x1E, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [1B] 0B D2 76 00 00 98 63 6F 72 65 61 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 14 00");

                    #region 80 E6 02 00 [1B] 0B D2 76 00 00 98 63 6F 72 65 61 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 14 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[27] { 0x0B, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x63, 0x6F, 0x72, 0x65, 0x61, 0x6F, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x14, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }

                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [1C] 0C D2 76 00 00 98 63 6F 72 65 62 69 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 16 00");

                    #region 80 E6 02 00 [1C] 0C D2 76 00 00 98 63 6F 72 65 62 69 6F 08 A0 00 00 01 51 00 00 00 00 03 35 01 16 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[28] { 0x0C, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x63, 0x6F, 0x72, 0x65, 0x62, 0x69, 0x6F, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x16, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [1D] 0D D2 76 00 00 98 63 6F 72 65 72 75 6C 65 08 A0 00 00 01 51 00 00 00 00 03 35 01 18 00");

                    #region 80 E6 02 00 [1D] 0D D2 76 00 00 98 63 6F 72 65 72 75 6C 65 08 A0 00 00 01 51 00 00 00 00 03 35 01 18 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[29] { 0x0D, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x63, 0x6F, 0x72, 0x65, 0x72, 0x75, 0x6C, 0x65, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x18, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [19] 09 D2 76 00 00 98 61 75 74 68 08 A0 00 00 01 51 00 00 00 00 03 35 01 1A 00");

                    #region 80 E6 02 00 [19] 09 D2 76 00 00 98 61 75 74 68 08 A0 00 00 01 51 00 00 00 00 03 35 01 1A 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[25] { 0x09, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x61, 0x75, 0x74, 0x68, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x1A, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [15] 05 D2 76 00 00 98 08 A0 00 00 01 51 00 00 00 00 03 35 01 24 00");

                    #region 80 E6 02 00 [15] 05 D2 76 00 00 98 08 A0 00 00 01 51 00 00 00 00 03 35 01 24 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[21] { 0x05, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x24, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [17] 07 D2 76 00 00 98 4D 44 08 A0 00 00 01 51 00 00 00 00 03 35 01 26 00");

                    #region 80 E6 02 00 [17] 07 D2 76 00 00 98 4D 44 08 A0 00 00 01 51 00 00 00 00 03 35 01 26 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[23] { 0x07, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x4D, 0x44, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x26, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [18] 08 D2 76 00 00 98 45 41 43 08 A0 00 00 01 51 00 00 00 00 03 35 01 28 00");

                    #region 80 E6 02 00 [18] 08 D2 76 00 00 98 45 41 43 08 A0 00 00 01 51 00 00 00 00 03 35 01 28 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[24] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x45, 0x41, 0x43, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x28, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [18] 08 D2 76 00 00 98 65 49 44 08 A0 00 00 01 51 00 00 00 00 03 35 01 22 00");

                    #region 80 E6 02 00 [18] 08 D2 76 00 00 98 65 49 44 08 A0 00 00 01 51 00 00 00 00 03 35 01 22 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[24] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x65, 0x49, 0x44, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x22, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                {
                    log.Info("80 E6 02 00 [18] 08 D2 76 00 00 98 50 4B 49 08 A0 00 00 01 51 00 00 00 00 03 35 01 2A 00");

                    #region 80 E6 02 00 [18] 08 D2 76 00 00 98 50 4B 49 08 A0 00 00 01 51 00 00 00 00 03 35 01 2A 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[24] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x50, 0x4B, 0x49, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x2A, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }


                {
                    log.Info("80 E6 02 00 [18] 08 D2 76 00 00 98 49 41 53 08 A0 00 00 01 51 00 00 00 00 03 35 01 20 00");

                    #region 80 E6 02 00 [18] 08 D2 76 00 00 98 49 41 53 08 A0 00 00 01 51 00 00 00 00 03 35 01 20 00

                    APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x02, 0x00, null, 1);

                    APDUParam apduParam5 = new APDUParam();

                    apduParam5.Data = new byte[24] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x49, 0x41, 0x53, 0x08, 0xA0, 0x00, 0x00, 0x01, 0x51, 0x00, 0x00, 0x00, 0x00, 0x03, 0x35, 0x01, 0x20, 0x00 };

                    apduSize5.Update(apduParam5);

                    apduResp = iCard.Transmit(apduSize5);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        extr.ExternalAuth();
                    }
                    else
                    {
                        installLoadFail = true;
                    }
                    #endregion

                    log.Info(apduResp.Status);
                    log.Info(apduResp.ToString());
                }

                if (!installLoadFail)
                {
                    LastOperationStatus = "Failed to install. See Logs";
                    log.Error("Failed to install");

                    return -100;
                }

                if (extr.ExternalAuth() != 0)
                {
                    LastOperationStatus = "ExternalAuth not estableshed";
                    log.Error(-35);

                    return -35;
                }

                {
                    #region 80 F0 80 07
                    APDUCommand apduSize2 = new APDUCommand(0x80, 0xF0, 0x80, 0x07, null, 0);

                    apduResp = iCard.Transmit(apduSize2);
                    if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                    {
                        LastOperationStatus = apduResp.ToString();
                        log.Error(apduResp.ToString());

                        return -36;
                    }
                    #endregion
                }

                if (mode == CardFactoryMode.DrivingLicence)
                {
                    /* SendApdu: GP.InstallForMakeSelectable DL APPLET
                     * 
                     * => 80 E6 0C 00 [24] 08 D2 76 00 00 98 45 41 43 07 A0 00 00 02 47 10 01 07 A0 00 00 02 48 02 00 01 08 07 C9 05 4C 00 00 42 0A 00
                        <= 009000
                     */

                    {
                        log.Info("80 E6 0C 00 [24] 08 D2 76 00 00 98 45 41 43 07 A0 00 00 02 47 10 01 07 A0 00 00 02 48 02 00 01 08 07 C9 05 4C 00 FD 42 42 00");

                        #region 80 E6 0C 00 [24] 08 D2 76 00 00 98 45 41 43 07 A0 00 00 02 47 10 01 07 A0 00 00 02 48 02 00 01 08 07 C9 05 4C 00 FD 42 42 00

                        APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x0C, 0x00, null, 1);

                        APDUParam apduParam5 = new APDUParam();

                        apduParam5.Data = new byte[36] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x45, 0x41, 0x43, 0x07, 0xA0, 0x00, 0x00, 0x02, 0x47, 0x10, 0x01, 0x07, 0xA0, 0x00, 0x00, 0x02, 0x48, 0x02, 0x00, 0x01, 0x08, 0x07, 0xC9, 0x05, 0x4C, 0x00, 0xFD, 0x42, 0x42, 0x00 };

                        apduSize5.Update(apduParam5);

                        apduResp = iCard.Transmit(apduSize5);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            if (apduResp.ToString().Contains("6A82"))
                            {
                                string code = "File Not Found";
                                LastOperationStatus = code;
                                log.Error(code);

                                return 100;
                            }

                            return 101;
                        }
                        #endregion

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }
                }
                else if (mode == CardFactoryMode.VehicleRegistration)
                {
                    /* SendApdu: GP.InstallForMakeSelectable VR APPLET
                     * 
                     * => 80 E6 0C 00 [24] 08 D2 76 00 00 98 45 41 43 07 A0 00 00 02 47 10 01 07 A0 00 00 02 47 10 01 01 08 07 C9 05 4C 00 00 42 0A 00
                        <= 009000
                     */

                    {
                        log.Info("80 E6 0C 00 [24] 08 D2 76 00 00 98 45 41 43 07 A0 00 00 02 47 10 01 07 A0 00 00 02 48 02 00 01 08 07 C9 05 4C 00 FD 42 42 00");

                        #region 80 E6 0C 00 [24] 08 D2 76 00 00 98 45 41 43 07 A0 00 00 02 47 10 01 07 A0 00 00 02 48 02 00 01 08 07 C9 05 4C 00 FD 42 42 00

                        APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x0C, 0x00, null, 0);

                        APDUParam apduParam5 = new APDUParam();

                        apduParam5.Data = new byte[36] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x45, 0x41, 0x43, 0x07, 0xA0, 0x00, 0x00, 0x02, 0x47, 0x10, 0x01, 0x07, 0xA0, 0x00, 0x00, 0x02, 0x47, 0x10, 0x01, 0x01, 0x08, 0x07, 0xC9, 0x05, 0x4C, 0x00, 0xFD, 0x42, 0x42, 0x00 };

                        apduSize5.Update(apduParam5);

                        apduResp = iCard.Transmit(apduSize5);
                        if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                        {
                            if (apduResp.ToString().Contains("6A82"))
                            {
                                string code = "File Not Found";
                                LastOperationStatus = code;
                                log.Error(code);

                                return 100;
                            }

                            return 101;
                        }
                        #endregion

                        log.Info(apduResp.Status);
                        log.Info(apduResp.ToString());
                    }
                }


                iCard.Disconnect(DISCONNECT.Reset);

            }
            catch (Exception ex)
            {
                log.Info(ex.Message);

                return 101;
            }

            return 0;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="certificate"></param>
        /// <returns></returns>
        public int SaveCertificate(string certificate)
        {

            if (Connect2Card() != 0)
            {
                log.Info("Connection Failed");
                return -1;
            }

            if (extr.ExternalAuth() != 0)
            {
                log.Info("External Authentification Failed");
                return -2;
            }

            /* SendApdu: GP.InstallForMakeSelectable PKI APPLET
            * 
            * => 80 E6 0C 00 [64] 08D276000098504B490CA000000063504B43532D31350CA000000063504B43532D313501043DC93B00431E820210649118010201020102010202040204020402040204020402040204FD0B05313131313131313131310B033131313131313131FFFF0000
               <= 009000
            */

            {
                log.Info("80 E6 0C 00 [64] 08D276000098504B490CA000000063504B43532D31350CA000000063504B43532D313501043DC93B00431E820210649118010201020102010202040204020402040204020402040204FD0B05313131313131313131310B033131313131313131FFFF0000");

                #region 80 E6 0C 00 [64] 08D276000098504B490CA000000063504B43532D31350CA000000063504B43532D313501043DC93B00431E820210649118010201020102010202040204020402040204020402040204FD0B05313131313131313131310B033131313131313131FFFF0000

                APDUCommand apduSize5 = new APDUCommand(0x80, 0xE6, 0x0C, 0x00, null, 0);

                APDUParam apduParam5 = new APDUParam();

                apduParam5.Data = new byte[100] { 0x08, 0xD2, 0x76, 0x00, 0x00, 0x98, 0x50, 0x4B, 0x49, 0x0C, 0xA0, 0x00, 0x00, 0x00, 0x63, 0x50, 0x4B, 0x43, 0x53, 0x2D, 0x31, 0x35, 0x0C, 0xA0, 0x00, 0x00, 0x00, 0x63, 0x50, 0x4B, 0x43, 0x53, 0x2D, 0x31, 0x35, 0x01, 0x04, 0x3D, 0xC9, 0x3B, 0x00, 0x43, 0x1E, 0x82, 0x02, 0x10, 0x64, 0x91, 0x18, 0x01, 0x02, 0x01, 0x02, 0x01, 0x02, 0x01, 0x02, 0x02, 0x04, 0x02, 0x04, 0x02, 0x04, 0x02, 0x04, 0x02, 0x04, 0x02, 0x04, 0x02, 0x04, 0x02, 0x04, 0xFD, 0x0B, 0x05, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x0B, 0x03, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0xFF, 0xFF, 0x00, 0x00 };

                apduSize5.Update(apduParam5);

                apduResp = iCard.Transmit(apduSize5);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {

                    log.Info(apduResp.ToString());

                    return -3;
                }
                #endregion

                log.Info(apduResp.Status);
                log.Info(apduResp.ToString());
            }

            /*
             * Select Applet 00A40400 [0C] A000000063504B43532D3135 [00] 
             */

            {
                log.Info("00A40400 [0C] A0 00 00 00 63 50 4B 43 53 2D 31 35 [00] ");

                #region 00A40400 [0C] A0 00 00 00 63 50 4B 43 53 2D 31 35 [00] 

                APDUCommand apduSize5 = new APDUCommand(0x00, 0xA4, 0x04, 0x00, null, 0);

                APDUParam apduParam5 = new APDUParam();

                apduParam5.Data = new byte[12] { 0xA0, 0x00, 0x00, 0x00, 0x63, 0x50, 0x4B, 0x43, 0x53, 0x2D, 0x31, 0x35 };

                apduSize5.Update(apduParam5);

                apduResp = iCard.Transmit(apduSize5);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {

                    log.Info(apduResp.ToString());

                    return -4;
                }
                #endregion

                log.Info(apduResp.Status);
                log.Info(apduResp.ToString());
            }

            /* GET DATA
             * 80CA0055 [00] 
             */

            {
                log.Info("80CA0055 [00] ");

                #region 80CA0055 [00] 

                APDUCommand apduSize5 = new APDUCommand(0x80, 0xCA, 0x00, 0x55, null, 0);

                apduResp = iCard.Transmit(apduSize5);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {

                    log.Info(apduResp.ToString());

                    return -5;
                }
                #endregion

                log.Info(apduResp.Status);
                log.Info(apduResp.ToString());
            }



            byte[] certificateByte = Encoding.UTF8.GetBytes(certificate);

            string hexValue = certificateByte.Length.ToString("X");

            byte fileLength  = Convert.ToByte(certificateByte.Length.ToString("X"), 16);

            /*
             * Create File
             */

            //00 E0 00 00 [17] 62|15 <80|02 <00D6>><82|01 <01>><83|02 <0001>><86|02 <060C>><88|01 <08>><8A|01 <05>>

            {
                log.Info("00 E0 00 00 [17] 62|15 <80|02 <00D6>><82|01 <01>><83|02 <0001>><86|02 <060C>><88|01 <08>><8A|01 <05>> ");

                #region 00 E0 00 00 [17] 62|15 <80|02 <00D6>><82|01 <01>><83|02 <0001>><86|02 <060C>><88|01 <08>><8A|01 <05>>

                APDUCommand apduSize5 = new APDUCommand(0x00, 0xE0, 0x00, 0x00, null, 0);

                APDUParam apduParam5 = new APDUParam();

                apduParam5.Data = new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, fileLength, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x01, 0x86, 0x02, 0x06, 0x0C, 0x88, 0x01 , 0x08, 0x8A, 0x01, 0x05 };

                apduSize5.Update(apduParam5);

                apduResp = iCard.Transmit(apduSize5);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {

                    log.Info(apduResp.ToString());

                    return -6;
                }
                #endregion

                log.Info(apduResp.Status);
                log.Info(apduResp.ToString());
            }


            /*
             *  Update BINARY
             */

            //00D60000 [1A] CERTIFICATE

            {
                log.Info("00D60000 [1A] CERTIFICATE ");

                #region 00D60000 [1A] CERTIFICATE

                APDUCommand apduSize5 = new APDUCommand(0x00, 0xD6, 0x00, 0x00, null, 0);

                APDUParam apduParam5 = new APDUParam();

                apduParam5.Data = certificateByte;

                apduSize5.Update(apduParam5);

                log.Info(apduSize5.ToString());

                apduResp = iCard.Transmit(apduSize5);
                if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
                {
                    return 0;
                }
                #endregion

                log.Info(apduResp.Status);
                log.Info(apduResp.ToString());
            }

            iCard.Disconnect(DISCONNECT.Reset);

            return 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int SaveIDL2Card(byte[] DG1, byte[] DG2, byte[] DG3, byte[] DG4, byte[] DG5, byte[] DGCommon)
        {
            log.Info("SaveIDL2Card");

            try
            {
                Connect2Card();


                //SendApdu: ISO7816.SelectFileByDFName
                if (CallApduCommandLe(0x00, 0xA4, 0x04, 0x00, new byte[07] { 0xA0, 0x00, 0x00, 0x02, 0x48, 0x02, 0x00 }, 28) != 0)
                {
                    return -1;
                }

                /*
                 *  # CreateBACKeys
                    # CreateDESKeys
                    # CreateKeyObjectSymm
                    # SendApdu: CV.CreateObject
                */
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x07, new byte[23] { 0x62, 0x15, 0x82, 0x02, 0x10, 0x64, 0x83, 0x02, 0x0A, 0x21, 0x86, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9A, 0x01, 0x00, 0x9B, 0x01, 0x00 }) != 0)
                {
                    return -2;
                }

                //CV.Perosnalization BAP keys K enc
                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[22] { 0x83, 0x02, 0x20, 0x01, 0x8F, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F }) != 0)
                {
                    return -3;
                }

                //CV.Perosnalization BAP keys MAC
                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[22] { 0x83, 0x02, 0x20, 0x03, 0x8F, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F }) != 0)
                {
                    return -4;
                }

                //# CreateAuthenticationObjectAOSec
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x06, new byte[23] { 0x62, 0x15, 0x82, 0x0C, 0x10, 0x43, 0x06, 0xF3, 0xB4, 0x30, 0x00, 0x21, 0xB8, 0x30, 0x00, 0x21, 0x83, 0x02, 0x01, 0x21, 0x86, 0x01, 0x0D }) != 0)
                {
                    return -5;
                }

                //# PrePersonalizeEAP
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x07, new byte[25] { 0x62, 0x17, 0x80, 0x02, 0x01, 0x00, 0x82, 0x02, 0x10, 0x59, 0x83, 0x02, 0x2A, 0x30, 0x86, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9E, 0x01, 0x00 }) != 0)
                {
                    return -6;
                }

                /*
                 *# CreateKeyObjectAsymm
                  # TLVList
                  # SendApdu: CV.CreateObject
                 */
                //CV.CreateObject
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x07, new byte[22] { 0x62, 0x14, 0x80, 0x02, 0x00, 0xE0, 0x82, 0x02, 0x10, 0x5A, 0x83, 0x02, 0x2A, 0xB0, 0x86, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }) != 0)
                {
                    return -7;
                }

                //CV.StoreData
                if (CallApduCommand(0x80, 0xE2, 0x00, 0x00, new byte[2] { 0xDF, 0xB0 }) != 0)
                {
                    return -8;
                }

                /*
                 *  # PrePersonalizeIDLDGs
                    # Create ICAO DG1
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0xD6, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x01, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x08, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -9;
                }


                /*
                 *  # Create IDL DG2
                 *  # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0x91, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x02, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x10, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -10;
                }

                /*
                 *  # Create IDL DG3
                 *  # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0x27, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x03, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x18, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -11;
                }


                /*
                 *  # Create IDL DG4
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x5D, 0xE9, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x04, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x20, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -12;
                }


                /*
                 *  # Create IDL DG5
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x15, 0x0D, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x05, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x28, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -13;
                }

                //Create DG11
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[20] { 0x62, 0x15, 0x80, 0x02, 0x15, 0x0D, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x11, 0x86, 0x02, 0x00, 0x00/*, 0x88, 0x01, 0x11,*/ ,0x8A, 0x01, 0x05 }) != 0)
                {
                    //return -131;
                }

                /*
                    # Create IDL DG7
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x0B, 0x63, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x07, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x38, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -14;
                }


                /*
                 *  # Create IDL DG14
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x01, 0x50, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x0E, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x70, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -15;
                }

                /*
                 *  # Create IDL COM
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0x5E, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x1E, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0xF0, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -16;
                }

                //ISO7816.CreateFile SOD
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x07, 0x05, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x1D, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0xE8, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -17;
                }

                //ISO7816.SelectFileByDFName
                if (CallApduCommandLe(0x00, 0xA4, 0x04, 0x00, new byte[07] { 0xA0, 0x00, 0x00, 0x02, 0x48, 0x02, 0x00 }, 28) != 0) {    return -18;  }

                /*
                 *      # WriteBACKeys
                        # WriteDESKeys
                 */
                if (CallApduCommandLe(0x00, 0xDB, 0x3F, 0xFF, new byte[44] { 0x70, 0x2A, 0xBF, 0x0A, 0x21, 0x26, 0xA2, 0x24, 0x90, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x91, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F }, 0) != 0) { return -18; }

                /*
                 *  # PersonalizeEAP
                    # SendApdu: CV.SelectObject
                 */
                if (CallApduCommand(0x80, 0xA4, 0x00, 0x07, new byte[02] { 0x2A, 0x30 }) != 0) { return -19; }

                /*
                 * 
                 */
                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x21, 0x01, 0x8F, 0x20, 0xA9, 0xFB, 0x57, 0xDB, 0xA1, 0xEE, 0xA9, 0xBC, 0x3E, 0x66, 0x0A, 0x90, 0x9D, 0x83, 0x8D, 0x72, 0x6E, 0x3B, 0xF6, 0x23, 0xD5, 0x26, 0x20, 0x28, 0x20, 0x13, 0x48, 0x1D, 0x1F, 0x6E, 0x53, 0x77 }) != 0) { return -20; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x22, 0x01, 0x8F, 0x20, 0x7D, 0x5A, 0x09, 0x75, 0xFC, 0x2C, 0x30, 0x57, 0xEE, 0xF6, 0x75, 0x30, 0x41, 0x7A, 0xFF, 0xE7, 0xFB, 0x80, 0x55, 0xC1, 0x26, 0xDC, 0x5C, 0x6C, 0xE9, 0x4A, 0x4B, 0x44, 0xF3, 0x30, 0xB5, 0xD9 }) != 0) { return -21; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x23, 0x01, 0x8F, 0x20, 0x26, 0xDC, 0x5C, 0x6C, 0xE9, 0x4A, 0x4B, 0x44, 0xF3, 0x30, 0xB5, 0xD9, 0xBB, 0xD7, 0x7C, 0xBF, 0x95, 0x84, 0x16, 0x29, 0x5C, 0xF7, 0xE1, 0xCE, 0x6B, 0xCC, 0xDC, 0x18, 0xFF, 0x8C, 0x07, 0xB6 }) != 0) { return -22; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[71] { 0x83, 0x02, 0x24, 0x01, 0x8F, 0x41, 0x04, 0x8B, 0xD2, 0xAE, 0xB9, 0xCB, 0x7E, 0x57, 0xCB, 0x2C, 0x4B, 0x48, 0x2F, 0xFC, 0x81, 0xB7, 0xAF, 0xB9, 0xDE, 0x27, 0xE1, 0xE3, 0xBD, 0x23, 0xC2, 0x3A, 0x44, 0x53, 0xBD, 0x9A, 0xCE, 0x32, 0x62, 0x54, 0x7E, 0xF8, 0x35, 0xC3, 0xDA, 0xC4, 0xFD, 0x97, 0xF8, 0x46, 0x1A, 0x14, 0x61, 0x1D, 0xC9, 0xC2, 0x77, 0x45, 0x13, 0x2D, 0xED, 0x8E, 0x54, 0x5C, 0x1D, 0x54, 0xC7, 0x2F, 0x04, 0x69, 0x97 }) != 0) { return -23; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x25, 0x01, 0x8F, 0x20, 0xA9, 0xFB, 0x57, 0xDB, 0xA1, 0xEE, 0xA9, 0xBC, 0x3E, 0x66, 0x0A, 0x90, 0x9D, 0x83, 0x8D, 0x71, 0x8C, 0x39, 0x7A, 0xA3, 0xB5, 0x61, 0xA6, 0xF7, 0x90, 0x1E, 0x0E, 0x82, 0x97, 0x48, 0x56, 0xA7 }) != 0) { return -24; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[07] { 0x83, 0x02, 0x26, 0x01, 0x8F, 0x01, 0x01 }) != 0) { return -25; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[07] { 0x83, 0x02, 0x00, 0x80, 0x8F, 0x01, 0x00 }) != 0) { return -26; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x28, 0x01, 0x8F, 0x20, 0x5E, 0xE4, 0x6A, 0xDD, 0xCC, 0x23, 0xF3, 0x7D, 0xFD, 0x08, 0x78, 0x7A, 0xD7, 0x87, 0x36, 0x82, 0xE3, 0x06, 0x43, 0x53, 0xDA, 0xF7, 0x54, 0x62, 0xCF, 0x83, 0x2E, 0x18, 0x74, 0xF8, 0x7C, 0xAE }) != 0) { return -27; }

                if (CallApduCommand(0x80, 0xA4, 0x00, 0x07, new byte[02] { 0x2A, 0xB0 }) != 0) { return -28; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x21, 0x01, 0x8F, 0x1C, 0xD7, 0xC1, 0x34, 0xAA, 0x26, 0x43, 0x66, 0x86, 0x2A, 0x18, 0x30, 0x25, 0x75, 0xD1, 0xD7, 0x87, 0xB0, 0x9F, 0x07, 0x57, 0x97, 0xDA, 0x89, 0xF5, 0x7E, 0xC8, 0xC0, 0xFF }) != 0) { return -29; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x22, 0x01, 0x8F, 0x1C, 0x68, 0xA5, 0xE6, 0x2C, 0xA9, 0xCE, 0x6C, 0x1C, 0x29, 0x98, 0x03, 0xA6, 0xC1, 0x53, 0x0B, 0x51, 0x4E, 0x18, 0x2A, 0xD8, 0xB0, 0x04, 0x2A, 0x59, 0xCA, 0xD2, 0x9F, 0x43 }) != 0) { return -30; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x23, 0x01, 0x8F, 0x1C, 0x25, 0x80, 0xF6, 0x3C, 0xCF, 0xE4, 0x41, 0x38, 0x87, 0x07, 0x13, 0xB1, 0xA9, 0x23, 0x69, 0xE3, 0x3E, 0x21, 0x35, 0xD2, 0x66, 0xDB, 0xB3, 0x72, 0x38, 0x6C, 0x40, 0x0B }) != 0) { return -31; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[63] { 0x83, 0x02, 0x24, 0x01, 0x8F, 0x39, 0x04, 0x0D, 0x90, 0x29, 0xAD, 0x2C, 0x7E, 0x5C, 0xF4, 0x34, 0x08, 0x23, 0xB2, 0xA8, 0x7D, 0xC6, 0x8C, 0x9E, 0x4C, 0xE3, 0x17, 0x4C, 0x1E, 0x6E, 0xFD, 0xEE, 0x12, 0xC0, 0x7D, 0x58, 0xAA, 0x56, 0xF7, 0x72, 0xC0, 0x72, 0x6F, 0x24, 0xC6, 0xB8, 0x9E, 0x4E, 0xCD, 0xAC, 0x24, 0x35, 0x4B, 0x9E, 0x99, 0xCA, 0xA3, 0xF6, 0xD3, 0x76, 0x14, 0x02, 0xCD }) != 0) { return -32; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x25, 0x01, 0x8F, 0x1C, 0xD7, 0xC1, 0x34, 0xAA, 0x26, 0x43, 0x66, 0x86, 0x2A, 0x18, 0x30, 0x25, 0x75, 0xD0, 0xFB, 0x98, 0xD1, 0x16, 0xBC, 0x4B, 0x6D, 0xDE, 0xBC, 0xA3, 0xA5, 0xA7, 0x93, 0x9F }) != 0) { return -33; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[07] { 0x83, 0x02, 0x26, 0x01, 0x8F, 0x01, 0x01 }) != 0) { return -34; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[63] { 0x83, 0x02, 0x27, 0x01, 0x8F, 0x39, 0x04, 0x48, 0x84, 0xDA, 0x55, 0x88, 0x06, 0x6F, 0x6B, 0xA1, 0x05, 0x60, 0xC9, 0x40, 0x60, 0xCD, 0xB6, 0xAB, 0xC6, 0x20, 0xD4, 0x71, 0x49, 0x8E, 0xF6, 0xBC, 0x9C, 0x1A, 0xE6, 0x48, 0x98, 0x73, 0xE0, 0x95, 0xBC, 0xE2, 0x5A, 0x5C, 0xB7, 0xF8, 0xFD, 0x7B, 0x97, 0xAC, 0x1A, 0x88, 0xD9, 0x37, 0x02, 0xCC, 0xF6, 0x18, 0x52, 0xEB, 0x9E, 0xCB, 0xAA }) != 0) { return -35; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x01, new byte[03] { 0xDF, 0xBB, 0x25 }) != 0) { return -36; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x02, new byte[17] { 0xDF, 0xB9, 0x41, 0x54, 0x43, 0x56, 0x43, 0x41, 0x5F, 0x4E, 0x58, 0x50, 0x30, 0x30, 0x30, 0x30, 0x31 }) != 0) { return -37; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x03, new byte[06] { 0xDF, 0xBA, 0x3F, 0xFF, 0xFF, 0xFF }) != 0) { return -38; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x04, new byte[08] { 0xDF, 0xBD, 0x01, 0x08, 0x00, 0x06, 0x02, 0x04 }) != 0) { return -39; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x05, new byte[12] { 0xDF, 0x11, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x58 }) != 0) { return -40; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x06, new byte[08] { 0xDF, 0x12, 0x01, 0x05, 0x00, 0x06, 0x02, 0x03 }) != 0) { return -41; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x01, DG1) != 0) { return -42; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x02, DG2) != 0) { return -43; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x03, DG3) != 0) { return -44; }

                if (DG4 != null)
                    if (CallApduCommandImage(0x00, 0xD7, 0x00, 0x04, DG4) != 0) { return -45; }

                if (DG5 != null)
                    if (CallApduCommandImage(0x00, 0xD7, 0x00, 0x05, DG5) != 0) { /*return -46;*/ }

                if (CallApduCommandImage(0x00, 0xD7, 0x00, 0x0B, new byte[] { 0x31, 0x32, 0x33, 0x34, 0x35}) != 0) { /*return -45;*/ }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x1E, DGCommon) != 0) { return -49; }

                if (CallApduCommandLe(0x80, 0xE2, 0x80, 0x00, new byte[05] { 0x98, 0x02, 0x00, 0x33, 0x01 }, 2) != 0) { return -47; }
            }
            catch (Exception)
            {

            }

            return 0;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="DG1"></param>
        /// <param name="DG2"></param>
        /// <param name="DG3"></param>
        /// <param name="DG4"></param>
        /// <param name="DG5"></param>
        /// <returns></returns>
        public int SaveeVr2Card(byte[] DG1, byte[] DG2, byte[] DG3, byte[] DG4, byte[] DG5)
        {
            log.Info("SaveeVr2Card");

            try
            {
                Connect2Card();


                //SendApdu: ISO7816.SelectFileByDFName
                if (CallApduCommandLe(0x00, 0xA4, 0x04, 0x00, new byte[07] { 0xA0, 0x00, 0x00, 0x02, 0x48, 0x02, 0x00 }, 28) != 0)
                {
                    return -1;
                }

                /*
                 *  # CreateBACKeys
                    # CreateDESKeys
                    # CreateKeyObjectSymm
                    # SendApdu: CV.CreateObject
                */
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x07, new byte[23] { 0x62, 0x15, 0x82, 0x02, 0x10, 0x64, 0x83, 0x02, 0x0A, 0x21, 0x86, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9A, 0x01, 0x00, 0x9B, 0x01, 0x00 }) != 0)
                {
                    return -2;
                }

                //CV.Perosnalization BAP keys K enc
                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[22] { 0x83, 0x02, 0x20, 0x01, 0x8F, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F }) != 0)
                {
                    return -3;
                }

                //CV.Perosnalization BAP keys MAC
                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[22] { 0x83, 0x02, 0x20, 0x03, 0x8F, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F }) != 0)
                {
                    return -4;
                }

                //# CreateAuthenticationObjectAOSec
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x06, new byte[23] { 0x62, 0x15, 0x82, 0x0C, 0x10, 0x43, 0x06, 0xF3, 0xB4, 0x30, 0x00, 0x21, 0xB8, 0x30, 0x00, 0x21, 0x83, 0x02, 0x01, 0x21, 0x86, 0x01, 0x0D }) != 0)
                {
                    return -5;
                }

                //# PrePersonalizeEAP
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x07, new byte[25] { 0x62, 0x17, 0x80, 0x02, 0x01, 0x00, 0x82, 0x02, 0x10, 0x59, 0x83, 0x02, 0x2A, 0x30, 0x86, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x9E, 0x01, 0x00 }) != 0)
                {
                    return -6;
                }

                /*
                 *# CreateKeyObjectAsymm
                  # TLVList
                  # SendApdu: CV.CreateObject
                 */
                //CV.CreateObject
                if (CallApduCommand(0x80, 0xE0, 0x00, 0x07, new byte[22] { 0x62, 0x14, 0x80, 0x02, 0x00, 0xE0, 0x82, 0x02, 0x10, 0x5A, 0x83, 0x02, 0x2A, 0xB0, 0x86, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }) != 0)
                {
                    return -7;
                }

                //CV.StoreData
                if (CallApduCommand(0x80, 0xE2, 0x00, 0x00, new byte[2] { 0xDF, 0xB0 }) != 0)
                {
                    return -8;
                }

                /*
                 *  # PrePersonalizeIDLDGs
                    # Create ICAO DG1
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0xD6, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x01, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x08, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -9;
                }


                /*
                 *  # Create IDL DG2
                 *  # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0x91, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x02, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x10, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -10;
                }

                /*
                 *  # Create IDL DG3
                 *  # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0x27, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x03, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x18, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -11;
                }


                /*
                 *  # Create IDL DG4
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x5D, 0xE9, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x04, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x20, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -12;
                }


                /*
                 *  # Create IDL DG5
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x15, 0x0D, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x05, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x28, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -13;
                }


                /*
                    # Create IDL DG7
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x0B, 0x63, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x07, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x38, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -14;
                }


                /*
                 *  # Create IDL DG14
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x01, 0x50, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x0E, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0x70, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -15;
                }

                /*
                 *  # Create IDL COM
                    # CreateFile
                 */
                //ISO7816.CreateFile
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x00, 0x5E, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x1E, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0xF0, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -16;
                }

                //ISO7816.CreateFile SOD
                if (CallApduCommand(0x00, 0xE0, 0x00, 0x00, new byte[23] { 0x62, 0x15, 0x80, 0x02, 0x07, 0x05, 0x82, 0x01, 0x01, 0x83, 0x02, 0x00, 0x1D, 0x86, 0x02, 0x00, 0x00, 0x88, 0x01, 0xE8, 0x8A, 0x01, 0x05 }) != 0)
                {
                    return -17;
                }

                //ISO7816.SelectFileByDFName
                if (CallApduCommandLe(0x00, 0xA4, 0x04, 0x00, new byte[07] { 0xA0, 0x00, 0x00, 0x02, 0x48, 0x02, 0x00 }, 28) != 0) { return -18; }

                /*
                 *      # WriteBACKeys
                        # WriteDESKeys
                 */
                if (CallApduCommandLe(0x00, 0xDB, 0x3F, 0xFF, new byte[44] { 0x70, 0x2A, 0xBF, 0x0A, 0x21, 0x26, 0xA2, 0x24, 0x90, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x91, 0x10, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F }, 0) != 0) { return -18; }

                /*
                 *  # PersonalizeEAP
                    # SendApdu: CV.SelectObject
                 */
                if (CallApduCommand(0x80, 0xA4, 0x00, 0x07, new byte[02] { 0x2A, 0x30 }) != 0) { return -19; }

                /*
                 * 
                 */
                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x21, 0x01, 0x8F, 0x20, 0xA9, 0xFB, 0x57, 0xDB, 0xA1, 0xEE, 0xA9, 0xBC, 0x3E, 0x66, 0x0A, 0x90, 0x9D, 0x83, 0x8D, 0x72, 0x6E, 0x3B, 0xF6, 0x23, 0xD5, 0x26, 0x20, 0x28, 0x20, 0x13, 0x48, 0x1D, 0x1F, 0x6E, 0x53, 0x77 }) != 0) { return -20; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x22, 0x01, 0x8F, 0x20, 0x7D, 0x5A, 0x09, 0x75, 0xFC, 0x2C, 0x30, 0x57, 0xEE, 0xF6, 0x75, 0x30, 0x41, 0x7A, 0xFF, 0xE7, 0xFB, 0x80, 0x55, 0xC1, 0x26, 0xDC, 0x5C, 0x6C, 0xE9, 0x4A, 0x4B, 0x44, 0xF3, 0x30, 0xB5, 0xD9 }) != 0) { return -21; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x23, 0x01, 0x8F, 0x20, 0x26, 0xDC, 0x5C, 0x6C, 0xE9, 0x4A, 0x4B, 0x44, 0xF3, 0x30, 0xB5, 0xD9, 0xBB, 0xD7, 0x7C, 0xBF, 0x95, 0x84, 0x16, 0x29, 0x5C, 0xF7, 0xE1, 0xCE, 0x6B, 0xCC, 0xDC, 0x18, 0xFF, 0x8C, 0x07, 0xB6 }) != 0) { return -22; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[71] { 0x83, 0x02, 0x24, 0x01, 0x8F, 0x41, 0x04, 0x8B, 0xD2, 0xAE, 0xB9, 0xCB, 0x7E, 0x57, 0xCB, 0x2C, 0x4B, 0x48, 0x2F, 0xFC, 0x81, 0xB7, 0xAF, 0xB9, 0xDE, 0x27, 0xE1, 0xE3, 0xBD, 0x23, 0xC2, 0x3A, 0x44, 0x53, 0xBD, 0x9A, 0xCE, 0x32, 0x62, 0x54, 0x7E, 0xF8, 0x35, 0xC3, 0xDA, 0xC4, 0xFD, 0x97, 0xF8, 0x46, 0x1A, 0x14, 0x61, 0x1D, 0xC9, 0xC2, 0x77, 0x45, 0x13, 0x2D, 0xED, 0x8E, 0x54, 0x5C, 0x1D, 0x54, 0xC7, 0x2F, 0x04, 0x69, 0x97 }) != 0) { return -23; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x25, 0x01, 0x8F, 0x20, 0xA9, 0xFB, 0x57, 0xDB, 0xA1, 0xEE, 0xA9, 0xBC, 0x3E, 0x66, 0x0A, 0x90, 0x9D, 0x83, 0x8D, 0x71, 0x8C, 0x39, 0x7A, 0xA3, 0xB5, 0x61, 0xA6, 0xF7, 0x90, 0x1E, 0x0E, 0x82, 0x97, 0x48, 0x56, 0xA7 }) != 0) { return -24; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[07] { 0x83, 0x02, 0x26, 0x01, 0x8F, 0x01, 0x01 }) != 0) { return -25; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[07] { 0x83, 0x02, 0x00, 0x80, 0x8F, 0x01, 0x00 }) != 0) { return -26; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[38] { 0x83, 0x02, 0x28, 0x01, 0x8F, 0x20, 0x5E, 0xE4, 0x6A, 0xDD, 0xCC, 0x23, 0xF3, 0x7D, 0xFD, 0x08, 0x78, 0x7A, 0xD7, 0x87, 0x36, 0x82, 0xE3, 0x06, 0x43, 0x53, 0xDA, 0xF7, 0x54, 0x62, 0xCF, 0x83, 0x2E, 0x18, 0x74, 0xF8, 0x7C, 0xAE }) != 0) { return -27; }

                if (CallApduCommand(0x80, 0xA4, 0x00, 0x07, new byte[02] { 0x2A, 0xB0 }) != 0) { return -28; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x21, 0x01, 0x8F, 0x1C, 0xD7, 0xC1, 0x34, 0xAA, 0x26, 0x43, 0x66, 0x86, 0x2A, 0x18, 0x30, 0x25, 0x75, 0xD1, 0xD7, 0x87, 0xB0, 0x9F, 0x07, 0x57, 0x97, 0xDA, 0x89, 0xF5, 0x7E, 0xC8, 0xC0, 0xFF }) != 0) { return -29; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x22, 0x01, 0x8F, 0x1C, 0x68, 0xA5, 0xE6, 0x2C, 0xA9, 0xCE, 0x6C, 0x1C, 0x29, 0x98, 0x03, 0xA6, 0xC1, 0x53, 0x0B, 0x51, 0x4E, 0x18, 0x2A, 0xD8, 0xB0, 0x04, 0x2A, 0x59, 0xCA, 0xD2, 0x9F, 0x43 }) != 0) { return -30; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x23, 0x01, 0x8F, 0x1C, 0x25, 0x80, 0xF6, 0x3C, 0xCF, 0xE4, 0x41, 0x38, 0x87, 0x07, 0x13, 0xB1, 0xA9, 0x23, 0x69, 0xE3, 0x3E, 0x21, 0x35, 0xD2, 0x66, 0xDB, 0xB3, 0x72, 0x38, 0x6C, 0x40, 0x0B }) != 0) { return -31; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[63] { 0x83, 0x02, 0x24, 0x01, 0x8F, 0x39, 0x04, 0x0D, 0x90, 0x29, 0xAD, 0x2C, 0x7E, 0x5C, 0xF4, 0x34, 0x08, 0x23, 0xB2, 0xA8, 0x7D, 0xC6, 0x8C, 0x9E, 0x4C, 0xE3, 0x17, 0x4C, 0x1E, 0x6E, 0xFD, 0xEE, 0x12, 0xC0, 0x7D, 0x58, 0xAA, 0x56, 0xF7, 0x72, 0xC0, 0x72, 0x6F, 0x24, 0xC6, 0xB8, 0x9E, 0x4E, 0xCD, 0xAC, 0x24, 0x35, 0x4B, 0x9E, 0x99, 0xCA, 0xA3, 0xF6, 0xD3, 0x76, 0x14, 0x02, 0xCD }) != 0) { return -32; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[34] { 0x83, 0x02, 0x25, 0x01, 0x8F, 0x1C, 0xD7, 0xC1, 0x34, 0xAA, 0x26, 0x43, 0x66, 0x86, 0x2A, 0x18, 0x30, 0x25, 0x75, 0xD0, 0xFB, 0x98, 0xD1, 0x16, 0xBC, 0x4B, 0x6D, 0xDE, 0xBC, 0xA3, 0xA5, 0xA7, 0x93, 0x9F }) != 0) { return -33; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[07] { 0x83, 0x02, 0x26, 0x01, 0x8F, 0x01, 0x01 }) != 0) { return -34; }

                if (CallApduCommand(0x80, 0xDA, 0x01, 0x6E, new byte[63] { 0x83, 0x02, 0x27, 0x01, 0x8F, 0x39, 0x04, 0x48, 0x84, 0xDA, 0x55, 0x88, 0x06, 0x6F, 0x6B, 0xA1, 0x05, 0x60, 0xC9, 0x40, 0x60, 0xCD, 0xB6, 0xAB, 0xC6, 0x20, 0xD4, 0x71, 0x49, 0x8E, 0xF6, 0xBC, 0x9C, 0x1A, 0xE6, 0x48, 0x98, 0x73, 0xE0, 0x95, 0xBC, 0xE2, 0x5A, 0x5C, 0xB7, 0xF8, 0xFD, 0x7B, 0x97, 0xAC, 0x1A, 0x88, 0xD9, 0x37, 0x02, 0xCC, 0xF6, 0x18, 0x52, 0xEB, 0x9E, 0xCB, 0xAA }) != 0) { return -35; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x01, new byte[03] { 0xDF, 0xBB, 0x25 }) != 0) { return -36; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x02, new byte[17] { 0xDF, 0xB9, 0x41, 0x54, 0x43, 0x56, 0x43, 0x41, 0x5F, 0x4E, 0x58, 0x50, 0x30, 0x30, 0x30, 0x30, 0x31 }) != 0) { return -37; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x03, new byte[06] { 0xDF, 0xBA, 0x3F, 0xFF, 0xFF, 0xFF }) != 0) { return -38; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x04, new byte[08] { 0xDF, 0xBD, 0x01, 0x08, 0x00, 0x06, 0x02, 0x04 }) != 0) { return -39; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x05, new byte[12] { 0xDF, 0x11, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x58 }) != 0) { return -40; }

                if (CallApduCommand(0x80, 0xE2, 0x00, 0x06, new byte[08] { 0xDF, 0x12, 0x01, 0x05, 0x00, 0x06, 0x02, 0x03 }) != 0) { return -41; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x01, DG1) != 0) { return -42; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x02, DG2) != 0) { return -43; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x03, DG3) != 0) { return -44; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x04, DG4) != 0) { return -45; }

                if (CallApduCommand(0x00, 0xD7, 0x00, 0x05, DG5) != 0) { return -46; }

                if (CallApduCommandLe(0x80, 0xE2, 0x80, 0x00, new byte[05] { 0x98, 0x02, 0x00, 0x33, 0x01 }, 2) != 0) { return -47; }

            }
            catch (Exception)
            {

            }

            return 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Cla"></param>
        /// <param name="Ins"></param>
        /// <param name="P1"></param>
        /// <param name="P2"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        private int CallApduCommand(byte Cla, byte Ins, byte P1, byte P2, byte [] data)
        {
            APDUCommand apduSize5 = new APDUCommand(Cla, Ins, P1, P2, null, 0);

            APDUParam apduParam5 = new APDUParam();

            apduParam5.Data = data;

            apduSize5.Update(apduParam5);

            apduResp = iCard.Transmit(apduSize5);
            if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
            {

                log.Info(apduResp.ToString());

                return -1;
            }

            log.Info(apduResp.Status);
            log.Info(apduResp.ToString());

            return 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Cla"></param>
        /// <param name="Ins"></param>
        /// <param name="P1"></param>
        /// <param name="P2"></param>
        /// <param name="data"></param>
        /// <param name="_recieveLength"></param>
        /// <returns></returns>
        private int CallApduCommandLe(byte Cla, byte Ins, byte P1, byte P2, byte[] data, uint _recieveLength)
        {
            APDUCommand apduSize5 = new APDUCommand(Cla, Ins, P1, P2, null, 0);

            APDUParam apduParam5 = new APDUParam();

            apduParam5.Data = data;

            apduSize5.Update(apduParam5);

            apduResp = iCard.TransmitLe(apduSize5, _recieveLength);
            if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
            {

                log.Info(apduResp.ToString());

                return -1;
            }

            log.Info(apduResp.Status);
            log.Info(apduResp.ToString());

            return 0;
        }


        private byte[] CallApduCommandLeData(byte Cla, byte Ins, byte P1, byte P2, byte[] data, uint _recieveLength)
        {
            APDUCommand apduSize5 = new APDUCommand(Cla, Ins, P1, P2, null, 0);

            APDUParam apduParam5 = new APDUParam();

            apduParam5.Data = data;

            apduSize5.Update(apduParam5);

            apduResp = iCard.TransmitLe(apduSize5, _recieveLength);
            if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING && apduResp.Status != SC_FileEnd)
            {

                log.Info(apduResp.ToString());

                return null;
            }

            log.Info(apduResp.Status);
            log.Info(apduResp.ToString());

            return apduResp.Data;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="Cla"></param>
        /// <param name="Ins"></param>
        /// <param name="P1"></param>
        /// <param name="P2"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        private int CallApduCommandImage(byte Cla, byte Ins, byte P1, byte P2, byte[] data)
        {
            APDUCommand apduSize5 = new APDUCommand(Cla, Ins, P1, P2, null, 0);

            APDUParam apduParam5 = new APDUParam();

            apduParam5.Data = data;

            apduSize5.Update(apduParam5);

            apduResp = iCard.TransmitImage(apduSize5);
            if (apduResp.Status != SC_OK && apduResp.SW1 != SC_PENDING)
            {

                log.Info(apduResp.ToString());

                return -1;
            }

            log.Info(apduResp.Status);
            log.Info(apduResp.ToString());

            return 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public int ReadIDLCard(ref byte[] DG1, ref byte[] DG2, ref byte[] DG3, ref byte[] DG4, ref byte[] DG5, ref byte[] DGCommon)
        {
            log.Info("ReadIDLCard");

            try
            {
                Connect2Card();

                var retValApplet = CallApduCommandLeData(0x00, 0xA4, 0x04, 0x00, new byte[07] { 0xA0, 0x00, 0x00, 0x02, 0x48, 0x02, 0x00 }, 28);

                if (retValApplet == null)
                {
                    return -1;
                }
                else
                {
                    //Do Some Action
                }

                #region DG1
                {
                    byte[] FileLength = new byte[2];

                    var retValFileDG1Param = CallApduCommandLeData(0x00, 0xA4, 0x02, 0x00, new byte[02] { 0x00, 0x01 }, 23);

                    if (retValFileDG1Param == null)
                    {
                        return -1;
                    }
                    else
                    {
                        FileLength[0] = retValFileDG1Param[8];
                        FileLength[1] = retValFileDG1Param[9];

                        //Do Convertion to int
                    }

                    var retValFileDG1Val = CallApduCommandLeData(0x00, 0xB0, 0x00, 0x00, null, 256);

                    if (retValFileDG1Val == null)
                    {
                        return -1;
                    }
                    else
                    {
                        DG1 = retValFileDG1Val;
                    }
                }
                #endregion


                #region DG2
                {
                    byte[] FileLength = new byte[2];

                    var retValFileDG1Param = CallApduCommandLeData(0x00, 0xA4, 0x02, 0x00, new byte[02] { 0x00, 0x02 }, 23);

                    if (retValFileDG1Param == null)
                    {
                        return -1;
                    }
                    else
                    {
                        FileLength[0] = retValFileDG1Param[8];
                        FileLength[1] = retValFileDG1Param[9];

                        //Do Convertion to int
                    }

                    var retValFileDG1Val = CallApduCommandLeData(0x00, 0xB0, 0x00, 0x00, null, 256);

                    if (retValFileDG1Val == null)
                    {
                        return -1;
                    }
                    else
                    {
                        DG2 = retValFileDG1Val;
                    }
                }
                #endregion


                #region DG3
                {
                    byte[] FileLength = new byte[2];

                    var retValFileDG1Param = CallApduCommandLeData(0x00, 0xA4, 0x02, 0x00, new byte[02] { 0x00, 0x03 }, 23);

                    if (retValFileDG1Param == null)
                    {
                        return -1;
                    }
                    else
                    {
                        FileLength[0] = retValFileDG1Param[8];
                        FileLength[1] = retValFileDG1Param[9];

                        //Do Convertion to int
                    }

                    var retValFileDG1Val = CallApduCommandLeData(0x00, 0xB0, 0x00, 0x00, null, 256);

                    if (retValFileDG1Val == null)
                    {
                        return -1;
                    }
                    else
                    {
                        DG3 = retValFileDG1Val;
                    }
                }
                #endregion


                #region DG4
                {
                    byte[] FileLength = new byte[2];

                    var retValFileDG1Param = CallApduCommandLeData(0x00, 0xA4, 0x02, 0x00, new byte[02] { 0x00, 0x04 }, 23);

                    if (retValFileDG1Param == null)
                    {
                        return -1;
                    }
                    else
                    {
                        FileLength[0] = retValFileDG1Param[8];
                        FileLength[1] = retValFileDG1Param[9];

                        //Do Convertion to int
                    }

                    var retValFileDG1Val = CallApduCommandLeData(0x00, 0xB0, 0x00, 0x00, null, 256);

                    if (retValFileDG1Val == null)
                    {
                        return -1;
                    }
                    else
                    {
                        DG4 = retValFileDG1Val;
                    }
                }
                #endregion


                #region DG5
                {
                    byte[] FileLength = new byte[2];

                    var retValFileDG1Param = CallApduCommandLeData(0x00, 0xA4, 0x02, 0x00, new byte[02] { 0x00, 0x05 }, 23);

                    if (retValFileDG1Param == null)
                    {
                        return -1;
                    }
                    else
                    {
                        FileLength[0] = retValFileDG1Param[8];
                        FileLength[1] = retValFileDG1Param[9];

                        //Do Convertion to int
                    }

                    var retValFileDG1Val = CallApduCommandLeData(0x00, 0xB0, 0x00, 0x00, null, 256);

                    if (retValFileDG1Val == null)
                    {
                        return -1;
                    }
                    else
                    {
                        DG5 = retValFileDG1Val;
                    }
                }
                #endregion


                #region DG Common
                {
                    byte[] FileLength = new byte[2];

                    var retValFileDG1Param = CallApduCommandLeData(0x00, 0xA4, 0x02, 0x00, new byte[02] { 0x00, 0x1E }, 23);

                    if (retValFileDG1Param == null)
                    {
                        return -1;
                    }
                    else
                    {
                        FileLength[0] = retValFileDG1Param[8];
                        FileLength[1] = retValFileDG1Param[9];

                        //Do Convertion to int
                    }

                    var retValFileDG1Val = CallApduCommandLeData(0x00, 0xB0, 0x00, 0x00, null, 255);

                    if (retValFileDG1Val == null)
                    {
                        return -1;
                    }
                    else
                    {
                        DGCommon = retValFileDG1Val;
                    }
                }
                #endregion

            }
            catch (Exception)
            {

            }


            return 0;
        }
    }
}
